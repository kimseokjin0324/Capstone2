package com.example.hearing;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.jvm.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;

import static android.media.AudioFormat.ENCODING_PCM_16BIT;

public class MainActivity extends AppCompatActivity {
    public static Listen listening;
    AudioDispatcher dispatcher;
    AudioProcessor pitchProcessor;
    TextView pitchText, noteText;
    public double[][] codes = new double[12][2];

    public void processPitch(float pitch) {
        pitchText.setText("" + pitch);

        if (pitch >= codes[0][0] && pitch < codes[0][1]) {
            noteText.setText("G#");
        } else if (pitch >= codes[1][0] && pitch < codes[1][1]) {
            noteText.setText("A");
        } else if (pitch >= codes[2][0] && pitch < codes[2][1]) {
            noteText.setText("A#");
        } else if (pitch >= codes[3][0] && pitch < codes[3][1]) {
            noteText.setText("B");
        } else if (pitch >= codes[4][0] && pitch < codes[4][1]) {
            noteText.setText("C");
        } else if (pitch >= codes[5][0] && pitch < codes[5][1]) {
            noteText.setText("C#");
        } else if (pitch >= codes[6][0] && pitch < codes[6][1]) {
            noteText.setText("D");
        } else if (pitch >= codes[7][0] && pitch < codes[7][1]) {
            noteText.setText("D#");
        } else if (pitch >= codes[8][0] && pitch < codes[8][1]) {
            noteText.setText("E");
        } else if (pitch >= codes[9][0] && pitch < codes[9][1]) {
            noteText.setText("F");
        } else if (pitch >= codes[10][0] && pitch < codes[10][1]) {
            noteText.setText("F#");
        } else if (pitch >= codes[11][0] && pitch < codes[11][1]) {
            noteText.setText("G");
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        codes[0][0] = 103.82; //G#
        codes[0][1] = 109.99;
        codes[1][0] = 110.00;//A
        codes[1][1] = 116.53;
        codes[2][0] = 116.54;//A#
        codes[2][1] = 123.46;
        codes[3][0] = 123.47;//B
        codes[3][1] = 130.80;
        codes[4][0] = 130.81;//C
        codes[4][1] = 138.58;
        codes[5][0] = 138.59;
        codes[5][1] = 146.81;
        codes[6][0] = 146.82;
        codes[6][1] = 155.55;
        codes[7][0] = 155.56;
        codes[7][1] = 164.80;
        codes[8][0] = 164.81;
        codes[8][1] = 174.60;
        codes[9][0] = 174.61;
        codes[9][1] = 184.98;
        codes[10][1] = 184.99;
        codes[10][1] = 195.98;
        codes[11][0] = 195.99;
        codes[11][1] = 207.65;

        noteText = (TextView) findViewById(R.id.noteText);
        pitchText = (TextView) findViewById(R.id.pitchText);

        listening = new Listen();
        listening.execute();

    }

    class Listen extends AsyncTask<Void, double[], Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            final int bufferSize = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT);
            dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(44100, bufferSize, bufferSize/2);
            PitchDetectionHandler pitch = new PitchDetectionHandler() {
                @Override
                public void handlePitch(PitchDetectionResult pitchDetectionResult, AudioEvent audioEvent) {
                    final float pitch = pitchDetectionResult.getPitch();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            processPitch(pitch);
                        }
                    });
                }

            };
            pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 44100, bufferSize, pitch);
            dispatcher.addAudioProcessor(pitchProcessor);
            dispatcher.run();
            return null;
        }
    }
}
